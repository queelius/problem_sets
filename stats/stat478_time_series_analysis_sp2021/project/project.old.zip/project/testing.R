setwd("~/proj")
data <- read.table(file="./data",sep=" ",header=TRUE)
